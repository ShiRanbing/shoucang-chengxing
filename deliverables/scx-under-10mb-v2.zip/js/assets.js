// 压缩发布包使用真实图片扩展名，保留项目数据中的素材键。
const UPLOAD_ASSET_ALIASES = {"cover-canal-bridge.jpg":"cover-canal-bridge.webp","cover-choose-your-day.jpg":"cover-choose-your-day.webp","cover-courtyard-meal.jpg":"cover-courtyard-meal.webp","cover-daily-concert.jpg":"cover-daily-concert.webp","cover-daily-journal.jpg":"cover-daily-journal.webp","cover-daily-makeup.jpg":"cover-daily-makeup.webp","cover-daily-nails.jpg":"cover-daily-nails.webp","cover-daily-outfit.jpg":"cover-daily-outfit.webp","cover-daily-room.jpg":"cover-daily-room.webp","cover-hill-afternoon.jpg":"cover-hill-afternoon.webp","cover-lake-and-table.jpg":"cover-lake-and-table.webp","cover-lake-walk.jpg":"cover-lake-walk.webp","cover-little-cats.jpg":"cover-little-cats.webp","cover-old-street.jpg":"cover-old-street.webp","cover-quiet-water.jpg":"cover-quiet-water.webp","cover-sh-anfu.jpg":"cover-sh-anfu.webp","cover-sh-bund.jpg":"cover-sh-bund.webp","cover-sh-coffee.jpg":"cover-sh-coffee.webp","cover-sh-westbund.jpg":"cover-sh-westbund.webp","cover-sh-wukang.jpg":"cover-sh-wukang.webp","cover-sh-yuyuan.jpg":"cover-sh-yuyuan.webp","cover-tea-time.jpg":"cover-tea-time.webp","pencil-atlas.png":"pencil-atlas.webp","retro-atlas.png":"retro-atlas.webp","shanghai-pencil-atlas.png":"shanghai-pencil-atlas.webp","shanghai-retro-atlas.png":"shanghai-retro-atlas.webp","shanghai-watercolor-atlas.png":"shanghai-watercolor-atlas.webp","watercolor-atlas.png":"watercolor-atlas.webp"};
import { landmarkFilename } from './landmarks.js';
export const CATEGORY_ORDER = ['nature', 'street', 'culture', 'food', 'coffee', 'other'];
const cache = new Map();
export function assetUrl(filename) { return new URL(`../assets/${UPLOAD_ASSET_ALIASES[filename] ?? filename}`, import.meta.url).href; }
export function atlasFilename(theme, city = '杭州') { return `${city === '上海' ? 'shanghai-' : ''}${theme}-atlas.png`; }
export async function loadAtlas(theme, city = '杭州') {
  return loadImage(atlasFilename(theme, city));
}
function loadImage(key) {
  if (cache.has(key)) return cache.get(key);
  const promise = new Promise(resolve => {
    const img = new Image();
    const timer = setTimeout(() => resolve(null), 12000);
    img.onload = () => { clearTimeout(timer); resolve(img); };
    img.onerror = () => { clearTimeout(timer); resolve(null); };
    img.src = assetUrl(key);
  });
  cache.set(key, promise);
  return promise;
}
export async function loadPosterAssets(project) {
  const items = project.stops.map(stop => project.inspirations.find(item => item.id === stop.inspirationId)).filter(Boolean);
  const filenames = [...new Set(items.map(item => landmarkFilename(item, project.theme)).filter(Boolean))];
  const [atlas, ...images] = await Promise.all([loadAtlas(project.theme, project.city), ...filenames.map(loadImage)]);
  const illustrations = new Map(filenames.map((filename, index) => [filename, images[index]]));
  const missing = filenames.filter(filename => !illustrations.get(filename));
  const needsAtlas = !items.length || items.some(item => !landmarkFilename(item, project.theme)) || missing.length > 0;
  return { atlas, illustrations, theme: project.theme, hasFallback: missing.length > 0 || (needsAtlas && !atlas) };
}
export function paintPlaceAsset(ctx, assets, item, x, y, size) {
  const image = assets.illustrations.get(landmarkFilename(item, assets.theme));
  if (!image) { paintAsset(ctx, assets.atlas, item.category, x, y, size); return; }
  // Keep the full landmark silhouette. The same source file is used in the inspiration card.
  const scale = Math.min(size / image.naturalWidth, size / image.naturalHeight);
  const width = image.naturalWidth * scale, height = image.naturalHeight * scale;
  ctx.drawImage(image, x + (size - width) / 2, y + (size - height) / 2, width, height);
}
export function paintAsset(ctx, atlas, category, x, y, size) {
  if (!atlas) {
    ctx.save(); ctx.strokeStyle = '#a0ac91'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(x + size * .22, y + size * .2, size * .56, size * .6, 20); ctx.stroke();
    ctx.font = `${size * .13}px serif`; ctx.textAlign = 'center'; ctx.fillStyle = '#819175'; ctx.fillText('✧', x + size / 2, y + size * .54); ctx.restore();
    return;
  }
  const index = Math.max(0, CATEGORY_ORDER.indexOf(category));
  const sw = atlas.naturalWidth / 2, sh = atlas.naturalHeight / 3;
  ctx.save();
  // Multiply integrates the pencil atlas's paper into the poster without modifying the source art.
  ctx.globalCompositeOperation = 'multiply';
  ctx.drawImage(atlas, index % 2 * sw, Math.floor(index / 2) * sh, sw, sh, x, y, size, size);
  ctx.restore();
}
